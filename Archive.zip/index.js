const express = require('express');
const nodemailer = require('nodemailer');
require('dotenv').config();

const app = express();
app.use(express.json());

// メール送信エンドポイント
app.post('/send-email', async (req, res) => {
    const { to, subject, text, html, inReplyTo, references } = req.body;

    // SMTP設定
    const transporter = nodemailer.createTransport({
        host: 'sv13188.xserver.jp', // XserverのSMTPサーバー
        port: 465,                  // SSLのポート
        secure: true,               // SSLを使用
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS
        }
    });

    // メール送信内容
    const mailOptions = {
        from: `"湯ヶ島たつた" <${process.env.SMTP_USER}>`,
        to,
        subject,
        text,
        html,
        headers: {
            'In-Reply-To': inReplyTo || undefined,
            'References': references || undefined
        }
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log('メールが送信されました:', info.response);
        res.status(200).send('メールが送信されました');
    } catch (error) {
        console.error('エラー:', error);
        res.status(500).send('メール送信に失敗しました');
    }
});

// ポート設定
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

